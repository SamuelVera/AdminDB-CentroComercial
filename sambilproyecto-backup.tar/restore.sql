--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sambilproyecto;
--
-- Name: sambilproyecto; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sambilproyecto WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Spanish_Spain.1252' LC_CTYPE = 'Spanish_Spain.1252';


ALTER DATABASE sambilproyecto OWNER TO postgres;

\connect sambilproyecto

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cantidadocupacionesmesa(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cantidadocupacionesmesa(mesa integer, fecha date) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
	DECLARE
		datum BIGINT;
	BEGIN
		SELECT COUNT(*) INTO datum
			FROM estadomesa
			WHERE idmesa=mesa
			AND ocupado=true
			AND EXTRACT(DAY FROM fechaestado)=EXTRACT(DAY FROM fecha)
			AND EXTRACT(MONTH FROM fechaestado)=EXTRACT(MONTH FROM fecha)
			AND EXTRACT(YEAR FROM fechaestado)=EXTRACT(YEAR FROM fecha);
		RETURN datum;
	END; $$;


ALTER FUNCTION public.cantidadocupacionesmesa(mesa integer, fecha date) OWNER TO postgres;

--
-- Name: checkfacturaespecial(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.checkfacturaespecial() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		IF(NEW.idsmartphone IS NOT NULL) THEN
			IF(
				NOT EXISTS 
				(
					SELECT numero
					FROM factura
					WHERE EXTRACT(DAY FROM fechacompra) = EXTRACT(DAY FROM NEW.fechacompra) 
					AND EXTRACT(MONTH FROM fechacompra) = EXTRACT(MONTH FROM NEW.fechacompra)
					AND EXTRACT(YEAR FROM fechacompra) = EXTRACT(YEAR FROM NEW.fechacompra)
					AND idsmartphone IS NOT NULL
				)
			)THEN
				EXECUTE insertprimerfacturadia(NEW.numero,NEW.fechacompra);
			END IF;
		END IF;
        RETURN NEW;
    END; $$;


ALTER FUNCTION public.checkfacturaespecial() OWNER TO postgres;

--
-- Name: flujosexopuerta(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.flujosexopuerta(numeropuerta integer) RETURNS TABLE(hombres bigint, mujeres bigint, puerta character varying)
    LANGUAGE plpgsql
    AS $$	BEGIN
		RETURN QUERY (
			SELECT (
				SELECT COUNT(*) 
				FROM accesoentrada AS a
				INNER JOIN puerta AS p
					ON a.idpuerta=p.numero
				WHERE 
					p.numero=numeropuerta
					AND
					a.sexo=0
					AND
					EXTRACT(MONTH FROM a.fechaacceso)=EXTRACT(MONTH FROM current_date)-1
					AND EXTRACT(YEAR FROM a.fechaacceso)=EXTRACT(YEAR FROM current_date)
				GROUP BY p.numero
			),
			(
				SELECT COUNT(*) 
				FROM accesoentrada AS a
				INNER JOIN puerta AS p
					ON a.idpuerta=p.numero
				WHERE 
					p.numero=numeropuerta
					AND
					a.sexo=1
					AND
					EXTRACT(MONTH FROM a.fechaacceso)=EXTRACT(MONTH FROM current_date)-1
					AND EXTRACT(YEAR FROM a.fechaacceso)=EXTRACT(YEAR FROM current_date)
				GROUP BY p.numero
			),
			(
				SELECT localizacion 
				FROM puerta 
				WHERE numero=numeropuerta
			)
		);
	END; $$;


ALTER FUNCTION public.flujosexopuerta(numeropuerta integer) OWNER TO postgres;

--
-- Name: gastosmartphone(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.gastosmartphone(smartphone integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
	DECLARE
			monto BIGINT;
	BEGIN
		SELECT CAST(SUM(f.monto) AS BIGINT) INTO monto 
			FROM factura AS f
			WHERE 
				EXTRACT(MONTH FROM fechacompra) = EXTRACT(MONTH FROM current_timestamp)-1
				AND
				EXTRACT(YEAR FROM fechacompra) = EXTRACT(YEAR FROM current_timestamp)
				AND f.idsmartphone IS NOT NULL
				AND f.idsmartphone = smartphone;
		RETURN monto;
	END; $$;


ALTER FUNCTION public.gastosmartphone(smartphone integer) OWNER TO postgres;

--
-- Name: insertprimerfacturadia(integer, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insertprimerfacturadia(n integer, f timestamp without time zone) RETURNS void
    LANGUAGE plpgsql
    AS $$
	BEGIN
		INSERT INTO primerfacturadia(idfactura, fecha)
		VALUES(n,f);
	END; $$;


ALTER FUNCTION public.insertprimerfacturadia(n integer, f timestamp without time zone) OWNER TO postgres;

--
-- Name: localessectorpiso(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.localessectorpiso(numerosector integer, numeropiso integer) RETURNS TABLE(sector character varying, piso character varying, codigolocal character varying, franquicias character varying)
    LANGUAGE plpgsql
    AS $$
	BEGIN
		RETURN QUERY(
			SELECT s.nombre,
			p.nombre,
			l.codigo,
			f.nombre
			FROM local AS l
			INNER JOIN franquicia AS f
				ON l.idfranquicia=f.id
			INNER JOIN piso AS p
				ON l.idpiso=p.numero
			INNER JOIN sector AS s
				ON l.idsector=s.id
			WHERE
				l.idsector=numerosector
				AND p.numero=numeropiso
		);
	END; $$;


ALTER FUNCTION public.localessectorpiso(numerosector integer, numeropiso integer) OWNER TO postgres;

--
-- Name: primerafacturames(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.primerafacturames(mes integer, anio integer) RETURNS TABLE(idfactura integer, fecha timestamp without time zone, ci integer, monto integer)
    LANGUAGE plpgsql
    AS $$
	BEGIN
		RETURN QUERY(
		SELECT f.numero, f.fechacompra, f.cicomprador, f.monto FROM factura AS f
		INNER JOIN primerfacturadia AS pf
			ON pf.idfactura = f.numero
		WHERE EXTRACT(MONTH FROM f.fechacompra)=mes
		AND EXTRACT(YEAR FROM f.fechacompra)=anio);
	END; $$;


ALTER FUNCTION public.primerafacturames(mes integer, anio integer) OWNER TO postgres;

--
-- Name: primerfacturadia(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.primerfacturadia() RETURNS trigger
    LANGUAGE plpgsql
    AS $$	BEGIN
		IF(NEW.idsmartphone IS NOT NULL) THEN
			IF(
				NOT EXISTS 
				(
					SELECT numero
					FROM factura
					WHERE EXTRACT(DAY FROM fechacompra) = EXTRACT(DAY FROM NEW.fechacompra) 
					AND EXTRACT(MONTH FROM fechacompra) = EXTRACT(MONTH FROM NEW.fechacompra)
					AND EXTRACT(YEAR FROM fechacompra) = EXTRACT(YEAR FROM NEW.fechacompra)
					AND idsmartphone IS NOT NULL
				)
			)THEN
				EXECUTE insertprimerfacturadia(NEW.numero,NEW.fechacompra);
			END IF;
		END IF;
        RETURN NEW;
    END; $$;


ALTER FUNCTION public.primerfacturadia() OWNER TO postgres;

--
-- Name: proc0(integer, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.proc0(idlocal integer, cicomprador integer, monto integer, idfactura integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
	DECLARE entrada TIMESTAMP WITHOUT TIME ZONE;
	DECLARE macaddress VARCHAR(40);
	BEGIN
    	SELECT e.fechaentrada INTO entrada
        FROM estadia AS e
        	INNER JOIN factura AS f ON f.idsmartphone = e.idsmartphone
        WHERE f.numero = idfactura
        	AND e.fechasalida IS NULL
        ORDER BY e.fechaentrada DESC
        LIMIT 1;

    	SELECT s.macaddress INTO macaddress
    	FROM smartphone AS s
    		INNER JOIN factura AS f ON f.idsmartphone = s.id
	    WHERE f.numero = idfactura;
		
		INSERT INTO facturaespecial(macaddress, entrada, monto, cicomprador, idfactura, idlocal)
	    VALUES (macaddress, entrada, monto, cicomprador, idfactura, idlocal);
		
	END; $$;


ALTER FUNCTION public.proc0(idlocal integer, cicomprador integer, monto integer, idfactura integer) OWNER TO postgres;

--
-- Name: ventasdetienda(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ventasdetienda(idfran integer) RETURNS TABLE(nombre character varying, local character varying, montoenventas bigint)
    LANGUAGE plpgsql
    AS $$
	BEGIN
		RETURN QUERY (
			SELECT fr.nombre, l.codigo, CAST( SUM(f.monto) AS BIGINT) AS montoenventas
			FROM local AS l
			INNER JOIN factura AS f
				ON l.id = f.idlocal
			INNER JOIN franquicia AS fr
				ON fr.id = l.idfranquicia
			WHERE l.idfranquicia=idfran
			GROUP BY l.id, fr.id
			ORDER BY montoenventas DESC
		);
	END; $$;


ALTER FUNCTION public.ventasdetienda(idfran integer) OWNER TO postgres;

--
-- Name: verificarincc(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verificarincc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		IF(NEW.idsmartphone IS NOT NULL) THEN
			IF (NEW.idsmartphone NOT IN 
				(SELECT idsmartphone 
				   FROM estadia 
				   WHERE fechasalida IS NULL
					AND idsmartphone = NEW.idsmartphone
					LIMIT 1)) THEN
				RAISE EXCEPTION 'El smartphone % no se encuentra en el cc, compra rechazada',NEW.idsmartphone;
			END IF;
		END IF;
		RETURN NEW;
	END; $$;


ALTER FUNCTION public.verificarincc() OWNER TO postgres;

--
-- Name: verificaroneincc(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verificaroneincc(smartphone integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
	BEGIN
		IF(smartphone IN (
			SELECT idsmartphone
			FROM estadia
			WHERE idsmartphone = smartphone
			AND fechasalida IS NULL
			ORDER BY fechaentrada DESC
			LIMIT 1
		))THEN
			RAISE INFO 'El smartphone se encuentra en el centro comercial';
			RETURN 'El smartphone se encuentra en el centro comercial';
		ELSE 
			RAISE INFO 'El smartphone no se encuentra en el centro comercial';
			RETURN 'El smartphone no se encuentra en el centro comercial';
		END IF;
		RETURN '';
	END; $$;


ALTER FUNCTION public.verificaroneincc(smartphone integer) OWNER TO postgres;

--
-- Name: verificarsentadoenmesa(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verificarsentadoenmesa(smartphone integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
	BEGIN
		IF(smartphone IN (
			SELECT idsmartphone
			FROM monitoreomesa
			WHERE idsmartphone=smartphone
			AND fechadesocupado IS NULL
			ORDER BY fechaocupado DESC
			LIMIT 1
		))THEN
			RAISE INFO 'El smartphone se encuentra en una mesa de feria';
			RETURN 'El smartphone se encuentra en una mesa de feria';
		ELSE
			RAISE INFO 'El smartphone no se encuentra en una mesa de feria';
			RETURN 'El smartphone no se encuentra en una mesa de feria';
	END IF;
	RETURN '';
	END; $$;


ALTER FUNCTION public.verificarsentadoenmesa(smartphone integer) OWNER TO postgres;

--
-- Name: verificarsmartphoneinlocalincc(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verificarsmartphoneinlocalincc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
         IF (NEW.idsmartphone NOT IN 
                (SELECT idsmartphone 
                FROM estadia 
                WHERE fechasalida IS NULL	
				AND idsmartphone=NEW.idsmartphone
				ORDER BY fechaentrada DESC
				LIMIT 1)) THEN
            RAISE EXCEPTION 
                'El smartphone % no se encuentra en el cc, a las % se detecto en el local %'
                ,NEW.idsmartphone,NEW.fechaentrada,NEW.idlocal;
        END IF;
        RETURN NEW;
    END; $$;


ALTER FUNCTION public.verificarsmartphoneinlocalincc() OWNER TO postgres;

--
-- Name: verificarsmartphoneinmesaincc(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verificarsmartphoneinmesaincc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
         IF (NEW.idsmartphone NOT IN 
                (SELECT idsmartphone 
                FROM estadia 
                WHERE fechasalida IS NULL
                AND idsmartphone = NEW.idsmartphone
                ORDER BY fechaentrada
                LIMIT 1)) THEN
            RAISE EXCEPTION 
                'El smartphone % no se encuentra en el cc, a las % se detecto en mesa %'
				,NEW.idsmartphone,NEW.fechaocupado,NEW.idmesa;
        END IF;
        RETURN NEW;
    END; 
	$$;


ALTER FUNCTION public.verificarsmartphoneinmesaincc() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: accesoentrada; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesoentrada (
    id integer NOT NULL,
    sexo integer NOT NULL,
    edad integer,
    fechaacceso timestamp(6) without time zone NOT NULL,
    idpuerta integer NOT NULL
);


ALTER TABLE public.accesoentrada OWNER TO postgres;

--
-- Name: accesoentrada_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accesoentrada_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accesoentrada_id_seq OWNER TO postgres;

--
-- Name: accesoentrada_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accesoentrada_id_seq OWNED BY public.accesoentrada.id;


--
-- Name: accesolocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesolocal (
    id integer NOT NULL,
    sexo integer NOT NULL,
    edad integer,
    fechaacceso timestamp without time zone NOT NULL,
    idlocal integer NOT NULL
);


ALTER TABLE public.accesolocal OWNER TO postgres;

--
-- Name: accesolocal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accesolocal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accesolocal_id_seq OWNER TO postgres;

--
-- Name: accesolocal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accesolocal_id_seq OWNED BY public.accesolocal.id;


--
-- Name: accesosporedadpuerta; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.accesosporedadpuerta AS
SELECT
    NULL::bigint AS flujo,
    NULL::text AS edad,
    NULL::character varying(40) AS puerta;


ALTER TABLE public.accesosporedadpuerta OWNER TO postgres;

--
-- Name: puerta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.puerta (
    numero integer NOT NULL,
    localizacion character varying(40) NOT NULL,
    idcc integer NOT NULL,
    emergencia boolean DEFAULT false NOT NULL
);


ALTER TABLE public.puerta OWNER TO postgres;

--
-- Name: accesosporpuertaemergencia; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.accesosporpuertaemergencia AS
 SELECT count(*) AS count
   FROM (public.accesoentrada ae
     JOIN public.puerta p ON ((ae.idpuerta = p.numero)))
  WHERE (p.emergencia = true);


ALTER TABLE public.accesosporpuertaemergencia OWNER TO postgres;

--
-- Name: accesosporsexopuerta; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.accesosporsexopuerta AS
SELECT
    NULL::bigint AS flujo,
    NULL::text AS sexo,
    NULL::character varying(40) AS puerta;


ALTER TABLE public.accesosporsexopuerta OWNER TO postgres;

--
-- Name: beacon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.beacon (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL
);


ALTER TABLE public.beacon OWNER TO postgres;

--
-- Name: beacon_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.beacon_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beacon_id_seq OWNER TO postgres;

--
-- Name: beacon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.beacon_id_seq OWNED BY public.beacon.id;


--
-- Name: camara; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.camara (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL
);


ALTER TABLE public.camara OWNER TO postgres;

--
-- Name: camara_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.camara_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.camara_id_seq OWNER TO postgres;

--
-- Name: camara_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.camara_id_seq OWNED BY public.camara.id;


--
-- Name: monitoreomesa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monitoreomesa (
    id integer NOT NULL,
    idsmartphone integer NOT NULL,
    idmesa integer NOT NULL,
    fechaocupado timestamp without time zone NOT NULL,
    fechadesocupado timestamp without time zone
);


ALTER TABLE public.monitoreomesa OWNER TO postgres;

--
-- Name: cantidadmesasocupadas; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.cantidadmesasocupadas AS
 SELECT count(*) AS mesasocupadas
   FROM public.monitoreomesa
  WHERE (monitoreomesa.fechadesocupado IS NULL);


ALTER TABLE public.cantidadmesasocupadas OWNER TO postgres;

--
-- Name: centrocomercial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.centrocomercial (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL
);


ALTER TABLE public.centrocomercial OWNER TO postgres;

--
-- Name: centrocomercial_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.centrocomercial_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.centrocomercial_id_seq OWNER TO postgres;

--
-- Name: centrocomercial_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.centrocomercial_id_seq OWNED BY public.centrocomercial.id;


--
-- Name: local; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.local (
    id integer NOT NULL,
    codigo character varying(40) NOT NULL,
    idpiso integer NOT NULL,
    idsector integer NOT NULL,
    idfranquicia integer NOT NULL
);


ALTER TABLE public.local OWNER TO postgres;

--
-- Name: recorrido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recorrido (
    id integer NOT NULL,
    idsmartphone integer NOT NULL,
    idlocal integer NOT NULL,
    fechaentrada timestamp without time zone NOT NULL,
    fechasalida timestamp without time zone
);


ALTER TABLE public.recorrido OWNER TO postgres;

--
-- Name: clientemasvisitasalocal; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.clientemasvisitasalocal AS
 SELECT DISTINCT ON (l.id) l.id AS local,
    r.idsmartphone AS smartphone,
    count(*) AS visitas
   FROM (public.recorrido r
     JOIN public.local l ON ((r.idlocal = l.id)))
  WHERE (date_part('year'::text, r.fechaentrada) = date_part('year'::text, CURRENT_DATE))
  GROUP BY l.id, r.idsmartphone
  ORDER BY l.id, (count(*)) DESC, r.idsmartphone;


ALTER TABLE public.clientemasvisitasalocal OWNER TO postgres;

--
-- Name: factura; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.factura (
    numero integer NOT NULL,
    cicomprador integer NOT NULL,
    idlocal integer NOT NULL,
    monto integer NOT NULL,
    fechacompra timestamp(4) without time zone NOT NULL,
    idsmartphone integer
);


ALTER TABLE public.factura OWNER TO postgres;

--
-- Name: compra_numero_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.compra_numero_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compra_numero_seq OWNER TO postgres;

--
-- Name: compra_numero_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.compra_numero_seq OWNED BY public.factura.numero;


--
-- Name: estadia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estadia (
    id integer NOT NULL,
    idsmartphone integer NOT NULL,
    fechaentrada timestamp without time zone NOT NULL,
    fechasalida timestamp without time zone,
    idpuertaentrada integer NOT NULL,
    idpuertasalida integer
);


ALTER TABLE public.estadia OWNER TO postgres;

--
-- Name: enccenmesaoenlocal; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.enccenmesaoenlocal AS
 SELECT ( SELECT count(*) AS count
           FROM (public.recorrido r
             JOIN public.estadia e ON ((r.idsmartphone = e.idsmartphone)))
          WHERE ((r.fechasalida IS NULL) AND (e.fechasalida IS NULL))) AS inlocal,
    ( SELECT count(*) AS count
           FROM (public.estadia e
             JOIN public.monitoreomesa mm ON ((e.idsmartphone = mm.idsmartphone)))
          WHERE ((e.fechasalida IS NULL) AND (mm.fechadesocupado IS NULL))) AS inmesa;


ALTER TABLE public.enccenmesaoenlocal OWNER TO postgres;

--
-- Name: estadomesa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estadomesa (
    id integer NOT NULL,
    idmesa integer NOT NULL,
    fechaestado timestamp without time zone NOT NULL,
    ocupado boolean NOT NULL
);


ALTER TABLE public.estadomesa OWNER TO postgres;

--
-- Name: estadomesa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estadomesa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estadomesa_id_seq OWNER TO postgres;

--
-- Name: estadomesa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estadomesa_id_seq OWNED BY public.estadomesa.id;


--
-- Name: facturaespecial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.facturaespecial (
    macaddress character varying(40) NOT NULL,
    entrada timestamp without time zone NOT NULL,
    monto integer NOT NULL,
    cicomprador integer NOT NULL,
    idlocal integer NOT NULL,
    idfactura integer NOT NULL
);


ALTER TABLE public.facturaespecial OWNER TO postgres;

--
-- Name: flujosectorpiso; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.flujosectorpiso AS
SELECT
    NULL::character varying(30) AS sector,
    NULL::text AS piso,
    NULL::bigint AS flujolocal;


ALTER TABLE public.flujosectorpiso OWNER TO postgres;

--
-- Name: franquicia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.franquicia (
    id integer NOT NULL,
    nombre character varying(40) NOT NULL
);


ALTER TABLE public.franquicia OWNER TO postgres;

--
-- Name: franquicia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.franquicia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.franquicia_id_seq OWNER TO postgres;

--
-- Name: franquicia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.franquicia_id_seq OWNED BY public.franquicia.id;


--
-- Name: local_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.local_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.local_id_seq OWNER TO postgres;

--
-- Name: local_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.local_id_seq OWNED BY public.local.id;


--
-- Name: sector; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sector (
    id integer NOT NULL,
    nombre character varying(30) NOT NULL,
    idcc integer NOT NULL
);


ALTER TABLE public.sector OWNER TO postgres;

--
-- Name: mastiempoporsector; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.mastiempoporsector AS
 SELECT DISTINCT ON (s.nombre) s.nombre AS sector,
    r.idsmartphone AS smartphone,
    sum((r.fechasalida - r.fechaentrada)) AS tiempo
   FROM ((public.recorrido r
     JOIN public.local l ON ((r.idlocal = l.id)))
     JOIN public.sector s ON ((l.idsector = s.id)))
  WHERE ((r.fechasalida IS NOT NULL) AND (date_part('month'::text, r.fechaentrada) = (date_part('month'::text, CURRENT_TIMESTAMP) - (1)::double precision)) AND (date_part('year'::text, r.fechaentrada) = date_part('year'::text, CURRENT_TIMESTAMP)))
  GROUP BY r.idsmartphone, s.nombre
  ORDER BY s.nombre DESC, (sum((r.fechasalida - r.fechaentrada))) DESC;


ALTER TABLE public.mastiempoporsector OWNER TO postgres;

--
-- Name: mesa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mesa (
    id integer NOT NULL
);


ALTER TABLE public.mesa OWNER TO postgres;

--
-- Name: mesa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mesa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mesa_id_seq OWNER TO postgres;

--
-- Name: mesa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mesa_id_seq OWNED BY public.mesa.id;


--
-- Name: monitoreomesa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.monitoreomesa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monitoreomesa_id_seq OWNER TO postgres;

--
-- Name: monitoreomesa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.monitoreomesa_id_seq OWNED BY public.monitoreomesa.id;


--
-- Name: piso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.piso (
    numero integer NOT NULL,
    nombre character varying(30) NOT NULL,
    idcc integer NOT NULL
);


ALTER TABLE public.piso OWNER TO postgres;

--
-- Name: porcentajeventassmartphone; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.porcentajeventassmartphone AS
 SELECT round((((( SELECT count(*) AS count
           FROM public.factura
          WHERE (factura.idsmartphone IS NULL)))::numeric * (100)::numeric) / (( SELECT count(*) AS count
           FROM public.factura))::numeric), 2) AS sinsmartphone,
    round((((( SELECT count(*) AS count
           FROM public.factura
          WHERE (factura.idsmartphone IS NOT NULL)))::numeric * (100)::numeric) / (( SELECT count(*) AS count
           FROM public.factura))::numeric), 2) AS consmartphone;


ALTER TABLE public.porcentajeventassmartphone OWNER TO postgres;

--
-- Name: primerfacturadia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.primerfacturadia (
    idfactura integer NOT NULL,
    fecha timestamp without time zone NOT NULL
);


ALTER TABLE public.primerfacturadia OWNER TO postgres;

--
-- Name: primerasventasultimomes; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.primerasventasultimomes AS
 SELECT pf.idfactura AS "numeroFactura",
    pf.fecha,
    f.cicomprador AS comprador,
    f.monto
   FROM (public.primerfacturadia pf
     JOIN public.factura f ON ((pf.idfactura = f.numero)))
  WHERE ((date_part('month'::text, pf.fecha) = (date_part('month'::text, CURRENT_DATE) - (1)::double precision)) AND (date_part('year'::text, pf.fecha) = date_part('year'::text, CURRENT_DATE)))
  ORDER BY pf.fecha;


ALTER TABLE public.primerasventasultimomes OWNER TO postgres;

--
-- Name: primerfacturadia_idfactura_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.primerfacturadia_idfactura_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.primerfacturadia_idfactura_seq OWNER TO postgres;

--
-- Name: primerfacturadia_idfactura_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.primerfacturadia_idfactura_seq OWNED BY public.primerfacturadia.idfactura;


--
-- Name: procentajeventassmartphone; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.procentajeventassmartphone AS
 SELECT round((((( SELECT count(*) AS count
           FROM public.factura
          WHERE (factura.idsmartphone IS NULL)))::numeric * (100)::numeric) / (( SELECT count(*) AS count
           FROM public.factura))::numeric), 2) AS sinsmartphone,
    round((((( SELECT count(*) AS count
           FROM public.factura
          WHERE (factura.idsmartphone IS NOT NULL)))::numeric * (100)::numeric) / (( SELECT count(*) AS count
           FROM public.factura))::numeric), 2) AS consmartphone;


ALTER TABLE public.procentajeventassmartphone OWNER TO postgres;

--
-- Name: recorrido_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recorrido_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recorrido_id_seq OWNER TO postgres;

--
-- Name: recorrido_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recorrido_id_seq OWNED BY public.estadia.id;


--
-- Name: recorrido_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recorrido_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recorrido_id_seq1 OWNER TO postgres;

--
-- Name: recorrido_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recorrido_id_seq1 OWNED BY public.recorrido.id;


--
-- Name: sensormesa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sensormesa (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL,
    idmesa integer
);


ALTER TABLE public.sensormesa OWNER TO postgres;

--
-- Name: sensormesa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sensormesa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sensormesa_id_seq OWNER TO postgres;

--
-- Name: sensormesa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sensormesa_id_seq OWNED BY public.sensormesa.id;


--
-- Name: smartphone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.smartphone (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL
);


ALTER TABLE public.smartphone OWNER TO postgres;

--
-- Name: smartphone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.smartphone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.smartphone_id_seq OWNER TO postgres;

--
-- Name: smartphone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.smartphone_id_seq OWNED BY public.smartphone.id;


--
-- Name: smartphonesencc; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.smartphonesencc AS
 SELECT count(*) AS count
   FROM public.estadia
  WHERE (estadia.fechasalida IS NULL);


ALTER TABLE public.smartphonesencc OWNER TO postgres;

--
-- Name: top5franquiciasventas; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.top5franquiciasventas AS
SELECT
    NULL::character varying(40) AS nombre,
    NULL::bigint AS total;


ALTER TABLE public.top5franquiciasventas OWNER TO postgres;

--
-- Name: top5localesflujopersonas; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.top5localesflujopersonas AS
SELECT
    NULL::character varying(40) AS franquicia,
    NULL::bigint AS flujopersonas;


ALTER TABLE public.top5localesflujopersonas OWNER TO postgres;

--
-- Name: top5mastiempo; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.top5mastiempo AS
 SELECT estadia.idsmartphone,
    sum((estadia.fechasalida - estadia.fechaentrada)) AS "Tiempo de estadia"
   FROM public.estadia
  WHERE ((estadia.fechasalida IS NOT NULL) AND (date_part('month'::text, estadia.fechaentrada) = (date_part('month'::text, CURRENT_DATE) - (1)::double precision)) AND (date_part('year'::text, estadia.fechaentrada) = date_part('year'::text, CURRENT_DATE)))
  GROUP BY estadia.idsmartphone
  ORDER BY (sum((estadia.fechasalida - estadia.fechaentrada))) DESC
 LIMIT 5;


ALTER TABLE public.top5mastiempo OWNER TO postgres;

--
-- Name: accesoentrada id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesoentrada ALTER COLUMN id SET DEFAULT nextval('public.accesoentrada_id_seq'::regclass);


--
-- Name: accesolocal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesolocal ALTER COLUMN id SET DEFAULT nextval('public.accesolocal_id_seq'::regclass);


--
-- Name: beacon id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beacon ALTER COLUMN id SET DEFAULT nextval('public.beacon_id_seq'::regclass);


--
-- Name: camara id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.camara ALTER COLUMN id SET DEFAULT nextval('public.camara_id_seq'::regclass);


--
-- Name: centrocomercial id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centrocomercial ALTER COLUMN id SET DEFAULT nextval('public.centrocomercial_id_seq'::regclass);


--
-- Name: estadia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadia ALTER COLUMN id SET DEFAULT nextval('public.recorrido_id_seq'::regclass);


--
-- Name: estadomesa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadomesa ALTER COLUMN id SET DEFAULT nextval('public.estadomesa_id_seq'::regclass);


--
-- Name: factura numero; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura ALTER COLUMN numero SET DEFAULT nextval('public.compra_numero_seq'::regclass);


--
-- Name: franquicia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.franquicia ALTER COLUMN id SET DEFAULT nextval('public.franquicia_id_seq'::regclass);


--
-- Name: local id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.local ALTER COLUMN id SET DEFAULT nextval('public.local_id_seq'::regclass);


--
-- Name: mesa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mesa ALTER COLUMN id SET DEFAULT nextval('public.mesa_id_seq'::regclass);


--
-- Name: monitoreomesa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitoreomesa ALTER COLUMN id SET DEFAULT nextval('public.monitoreomesa_id_seq'::regclass);


--
-- Name: primerfacturadia idfactura; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.primerfacturadia ALTER COLUMN idfactura SET DEFAULT nextval('public.primerfacturadia_idfactura_seq'::regclass);


--
-- Name: recorrido id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recorrido ALTER COLUMN id SET DEFAULT nextval('public.recorrido_id_seq1'::regclass);


--
-- Name: sensormesa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensormesa ALTER COLUMN id SET DEFAULT nextval('public.sensormesa_id_seq'::regclass);


--
-- Name: smartphone id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphone ALTER COLUMN id SET DEFAULT nextval('public.smartphone_id_seq'::regclass);


--
-- Data for Name: accesoentrada; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accesoentrada (id, sexo, edad, fechaacceso, idpuerta) FROM stdin;
\.
COPY public.accesoentrada (id, sexo, edad, fechaacceso, idpuerta) FROM '$$PATH$$/3107.dat';

--
-- Data for Name: accesolocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accesolocal (id, sexo, edad, fechaacceso, idlocal) FROM stdin;
\.
COPY public.accesolocal (id, sexo, edad, fechaacceso, idlocal) FROM '$$PATH$$/3109.dat';

--
-- Data for Name: beacon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.beacon (id, macaddress) FROM stdin;
\.
COPY public.beacon (id, macaddress) FROM '$$PATH$$/3090.dat';

--
-- Data for Name: camara; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.camara (id, macaddress) FROM stdin;
\.
COPY public.camara (id, macaddress) FROM '$$PATH$$/3097.dat';

--
-- Data for Name: centrocomercial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.centrocomercial (id, nombre) FROM stdin;
\.
COPY public.centrocomercial (id, nombre) FROM '$$PATH$$/3086.dat';

--
-- Data for Name: estadia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estadia (id, idsmartphone, fechaentrada, fechasalida, idpuertaentrada, idpuertasalida) FROM stdin;
\.
COPY public.estadia (id, idsmartphone, fechaentrada, fechasalida, idpuertaentrada, idpuertasalida) FROM '$$PATH$$/3117.dat';

--
-- Data for Name: estadomesa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estadomesa (id, idmesa, fechaestado, ocupado) FROM stdin;
\.
COPY public.estadomesa (id, idmesa, fechaestado, ocupado) FROM '$$PATH$$/3113.dat';

--
-- Data for Name: factura; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.factura (numero, cicomprador, idlocal, monto, fechacompra, idsmartphone) FROM stdin;
\.
COPY public.factura (numero, cicomprador, idlocal, monto, fechacompra, idsmartphone) FROM '$$PATH$$/3103.dat';

--
-- Data for Name: facturaespecial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.facturaespecial (macaddress, entrada, monto, cicomprador, idlocal, idfactura) FROM stdin;
\.
COPY public.facturaespecial (macaddress, entrada, monto, cicomprador, idlocal, idfactura) FROM '$$PATH$$/3120.dat';

--
-- Data for Name: franquicia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.franquicia (id, nombre) FROM stdin;
\.
COPY public.franquicia (id, nombre) FROM '$$PATH$$/3095.dat';

--
-- Data for Name: local; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.local (id, codigo, idpiso, idsector, idfranquicia) FROM stdin;
\.
COPY public.local (id, codigo, idpiso, idsector, idfranquicia) FROM '$$PATH$$/3101.dat';

--
-- Data for Name: mesa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mesa (id) FROM stdin;
\.
COPY public.mesa (id) FROM '$$PATH$$/3099.dat';

--
-- Data for Name: monitoreomesa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monitoreomesa (id, idsmartphone, idmesa, fechaocupado, fechadesocupado) FROM stdin;
\.
COPY public.monitoreomesa (id, idsmartphone, idmesa, fechaocupado, fechadesocupado) FROM '$$PATH$$/3111.dat';

--
-- Data for Name: piso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.piso (numero, nombre, idcc) FROM stdin;
\.
COPY public.piso (numero, nombre, idcc) FROM '$$PATH$$/3092.dat';

--
-- Data for Name: primerfacturadia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.primerfacturadia (idfactura, fecha) FROM stdin;
\.
COPY public.primerfacturadia (idfactura, fecha) FROM '$$PATH$$/3115.dat';

--
-- Data for Name: puerta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.puerta (numero, localizacion, idcc, emergencia) FROM stdin;
\.
COPY public.puerta (numero, localizacion, idcc, emergencia) FROM '$$PATH$$/3091.dat';

--
-- Data for Name: recorrido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recorrido (id, idsmartphone, idlocal, fechaentrada, fechasalida) FROM stdin;
\.
COPY public.recorrido (id, idsmartphone, idlocal, fechaentrada, fechasalida) FROM '$$PATH$$/3119.dat';

--
-- Data for Name: sector; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sector (id, nombre, idcc) FROM stdin;
\.
COPY public.sector (id, nombre, idcc) FROM '$$PATH$$/3093.dat';

--
-- Data for Name: sensormesa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sensormesa (id, macaddress, idmesa) FROM stdin;
\.
COPY public.sensormesa (id, macaddress, idmesa) FROM '$$PATH$$/3088.dat';

--
-- Data for Name: smartphone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.smartphone (id, macaddress) FROM stdin;
\.
COPY public.smartphone (id, macaddress) FROM '$$PATH$$/3105.dat';

--
-- Name: accesoentrada_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accesoentrada_id_seq', 6984, true);


--
-- Name: accesolocal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accesolocal_id_seq', 14404, true);


--
-- Name: beacon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.beacon_id_seq', 21, true);


--
-- Name: camara_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.camara_id_seq', 21, true);


--
-- Name: centrocomercial_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.centrocomercial_id_seq', 1, true);


--
-- Name: compra_numero_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compra_numero_seq', 5067, true);


--
-- Name: estadomesa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estadomesa_id_seq', 6398, true);


--
-- Name: franquicia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.franquicia_id_seq', 9, true);


--
-- Name: local_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.local_id_seq', 17, true);


--
-- Name: mesa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mesa_id_seq', 1, false);


--
-- Name: monitoreomesa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.monitoreomesa_id_seq', 2371, true);


--
-- Name: primerfacturadia_idfactura_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.primerfacturadia_idfactura_seq', 1, false);


--
-- Name: recorrido_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recorrido_id_seq', 4746, true);


--
-- Name: recorrido_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recorrido_id_seq1', 5319, true);


--
-- Name: sensormesa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sensormesa_id_seq', 10, true);


--
-- Name: smartphone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.smartphone_id_seq', 1, false);


--
-- Name: accesoentrada accesoentrada_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesoentrada
    ADD CONSTRAINT accesoentrada_pkey PRIMARY KEY (id);


--
-- Name: accesolocal accesolocal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesolocal
    ADD CONSTRAINT accesolocal_pkey PRIMARY KEY (id);


--
-- Name: beacon beacon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beacon
    ADD CONSTRAINT beacon_pkey PRIMARY KEY (id);


--
-- Name: camara camara_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.camara
    ADD CONSTRAINT camara_pkey PRIMARY KEY (id);


--
-- Name: centrocomercial centrocomercial_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centrocomercial
    ADD CONSTRAINT centrocomercial_pkey PRIMARY KEY (id);


--
-- Name: estadia estadia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadia
    ADD CONSTRAINT estadia_pkey PRIMARY KEY (id);


--
-- Name: estadomesa estadomesa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadomesa
    ADD CONSTRAINT estadomesa_pkey PRIMARY KEY (id);


--
-- Name: factura factura_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT factura_pkey PRIMARY KEY (numero);


--
-- Name: facturaespecial facturaespecial_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.facturaespecial
    ADD CONSTRAINT facturaespecial_pkey PRIMARY KEY (idfactura);


--
-- Name: franquicia franquicia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.franquicia
    ADD CONSTRAINT franquicia_pkey PRIMARY KEY (id);


--
-- Name: local local_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.local
    ADD CONSTRAINT local_pkey PRIMARY KEY (id);


--
-- Name: mesa mesa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mesa
    ADD CONSTRAINT mesa_pkey PRIMARY KEY (id);


--
-- Name: monitoreomesa monitoreomesa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitoreomesa
    ADD CONSTRAINT monitoreomesa_pkey PRIMARY KEY (id);


--
-- Name: piso piso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.piso
    ADD CONSTRAINT piso_pkey PRIMARY KEY (numero);


--
-- Name: primerfacturadia primerfacturadia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.primerfacturadia
    ADD CONSTRAINT primerfacturadia_pkey PRIMARY KEY (idfactura);


--
-- Name: puerta puerta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.puerta
    ADD CONSTRAINT puerta_pkey PRIMARY KEY (numero);


--
-- Name: recorrido recorrido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recorrido
    ADD CONSTRAINT recorrido_pkey PRIMARY KEY (id);


--
-- Name: sector sector_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sector
    ADD CONSTRAINT sector_pkey PRIMARY KEY (id);


--
-- Name: sensormesa sensormesa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensormesa
    ADD CONSTRAINT sensormesa_pkey PRIMARY KEY (id);


--
-- Name: smartphone smartphone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphone
    ADD CONSTRAINT smartphone_pkey PRIMARY KEY (id);


--
-- Name: top5localesflujopersonas _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.top5localesflujopersonas AS
 SELECT f.nombre AS franquicia,
    count(*) AS flujopersonas
   FROM ((public.franquicia f
     JOIN public.local l ON ((f.id = l.idfranquicia)))
     JOIN public.accesolocal al ON ((l.id = al.idlocal)))
  WHERE ((date_part('month'::text, al.fechaacceso) = (date_part('month'::text, CURRENT_DATE) - (1)::double precision)) AND (date_part('year'::text, al.fechaacceso) = date_part('year'::text, CURRENT_DATE)))
  GROUP BY f.id
  ORDER BY (count(*)) DESC
 LIMIT 5;


--
-- Name: accesosporsexopuerta _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.accesosporsexopuerta WITH (security_barrier='false') AS
 SELECT count(*) AS flujo,
        CASE
            WHEN (a.sexo = 0) THEN 'Hombres'::text
            WHEN (a.sexo = 1) THEN 'Mujeres'::text
            WHEN (a.sexo = 2) THEN 'No identificado'::text
            ELSE NULL::text
        END AS sexo,
    p.localizacion AS puerta
   FROM (public.accesoentrada a
     JOIN public.puerta p ON ((a.idpuerta = p.numero)))
  WHERE ((date_part('month'::text, a.fechaacceso) = (date_part('month'::text, CURRENT_DATE) - (1)::double precision)) AND (date_part('year'::text, a.fechaacceso) = date_part('year'::text, CURRENT_DATE)) AND (p.emergencia = false))
  GROUP BY p.numero, a.sexo
  ORDER BY (count(*)) DESC;


--
-- Name: accesosporedadpuerta _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.accesosporedadpuerta WITH (security_barrier='false') AS
 SELECT count(*) AS flujo,
        CASE
            WHEN (a.edad <= 12) THEN 'Infantes -12'::text
            WHEN ((a.edad >= 12) AND (a.edad <= 20)) THEN 'Adolescentes 13-19'::text
            WHEN ((a.edad >= 20) AND (a.edad <= 30)) THEN 'Jovenes 20-30'::text
            WHEN ((a.edad >= 30) AND (a.edad <= 60)) THEN 'Adultos 30-60'::text
            WHEN (a.edad >= 60) THEN 'Tercera Edad +60'::text
            ELSE NULL::text
        END AS edad,
    p.localizacion AS puerta
   FROM (public.accesoentrada a
     JOIN public.puerta p ON ((a.idpuerta = p.numero)))
  WHERE ((date_part('month'::text, a.fechaacceso) = (date_part('month'::text, CURRENT_DATE) - (1)::double precision)) AND (date_part('year'::text, a.fechaacceso) = date_part('year'::text, CURRENT_DATE)) AND (p.emergencia = false))
  GROUP BY
        CASE
            WHEN (a.edad <= 12) THEN 'Infantes -12'::text
            WHEN ((a.edad >= 12) AND (a.edad <= 20)) THEN 'Adolescentes 13-19'::text
            WHEN ((a.edad >= 20) AND (a.edad <= 30)) THEN 'Jovenes 20-30'::text
            WHEN ((a.edad >= 30) AND (a.edad <= 60)) THEN 'Adultos 30-60'::text
            WHEN (a.edad >= 60) THEN 'Tercera Edad +60'::text
            ELSE NULL::text
        END, p.numero
  ORDER BY (count(*)) DESC;


--
-- Name: top5franquiciasventas _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.top5franquiciasventas AS
 SELECT fr.nombre,
    sum(f.monto) AS total
   FROM ((public.factura f
     JOIN public.local l ON ((f.idlocal = l.id)))
     JOIN public.franquicia fr ON ((l.idfranquicia = fr.id)))
  WHERE ((date_part('month'::text, f.fechacompra) = (date_part('month'::text, CURRENT_DATE) - (1)::double precision)) AND (date_part('year'::text, f.fechacompra) = date_part('year'::text, CURRENT_DATE)))
  GROUP BY fr.id
  ORDER BY (sum(f.monto)) DESC
 LIMIT 5;


--
-- Name: flujosectorpiso _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.flujosectorpiso AS
 SELECT s.nombre AS sector,
    concat(p.nombre, '(', p.numero, ')') AS piso,
    count(*) AS flujolocal
   FROM (((public.accesolocal al
     JOIN public.local l ON ((al.idlocal = l.id)))
     JOIN public.sector s ON ((l.idsector = s.id)))
     JOIN public.piso p ON ((l.idpiso = p.numero)))
  GROUP BY s.nombre, p.numero
  ORDER BY p.numero, s.nombre;


--
-- Name: factura checkfacturaespecialtrig; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER checkfacturaespecialtrig AFTER INSERT ON public.factura FOR EACH ROW EXECUTE PROCEDURE public.checkfacturaespecial();


--
-- Name: factura primerfacturadiatrigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER primerfacturadiatrigger BEFORE INSERT ON public.factura FOR EACH ROW EXECUTE PROCEDURE public.primerfacturadia();


--
-- Name: factura verificarincctrigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER verificarincctrigger BEFORE INSERT ON public.factura FOR EACH ROW EXECUTE PROCEDURE public.verificarincc();


--
-- Name: recorrido verificarsmartphoneinlocalincctrig; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER verificarsmartphoneinlocalincctrig BEFORE INSERT ON public.recorrido FOR EACH ROW EXECUTE PROCEDURE public.verificarsmartphoneinlocalincc();


--
-- Name: monitoreomesa verificarsmartphoneinmesaincctrig; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER verificarsmartphoneinmesaincctrig BEFORE INSERT ON public.monitoreomesa FOR EACH ROW EXECUTE PROCEDURE public.verificarsmartphoneinmesaincc();


--
-- Name: puerta fkey_cc_puerta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.puerta
    ADD CONSTRAINT fkey_cc_puerta FOREIGN KEY (idcc) REFERENCES public.centrocomercial(id);


--
-- Name: sector fkey_cc_sector; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sector
    ADD CONSTRAINT fkey_cc_sector FOREIGN KEY (idcc) REFERENCES public.centrocomercial(id);


--
-- Name: facturaespecial fkey_factura_facturaespecial; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.facturaespecial
    ADD CONSTRAINT fkey_factura_facturaespecial FOREIGN KEY (idfactura) REFERENCES public.factura(numero) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: local fkey_franquicia_local; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.local
    ADD CONSTRAINT fkey_franquicia_local FOREIGN KEY (idfranquicia) REFERENCES public.franquicia(id);


--
-- Name: accesolocal fkey_local_accesolocal; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesolocal
    ADD CONSTRAINT fkey_local_accesolocal FOREIGN KEY (idlocal) REFERENCES public.local(id);


--
-- Name: factura fkey_local_factura; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT fkey_local_factura FOREIGN KEY (idlocal) REFERENCES public.local(id);


--
-- Name: recorrido fkey_local_recorrido; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recorrido
    ADD CONSTRAINT fkey_local_recorrido FOREIGN KEY (idlocal) REFERENCES public.local(id);


--
-- Name: estadomesa fkey_mesa_estadomesa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadomesa
    ADD CONSTRAINT fkey_mesa_estadomesa FOREIGN KEY (idmesa) REFERENCES public.mesa(id);


--
-- Name: monitoreomesa fkey_mesa_monitoreomesa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitoreomesa
    ADD CONSTRAINT fkey_mesa_monitoreomesa FOREIGN KEY (idmesa) REFERENCES public.mesa(id);


--
-- Name: sensormesa fkey_mesa_sensormesa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensormesa
    ADD CONSTRAINT fkey_mesa_sensormesa FOREIGN KEY (idmesa) REFERENCES public.mesa(id);


--
-- Name: piso fkey_piso_cc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.piso
    ADD CONSTRAINT fkey_piso_cc FOREIGN KEY (idcc) REFERENCES public.centrocomercial(id);


--
-- Name: local fkey_piso_local; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.local
    ADD CONSTRAINT fkey_piso_local FOREIGN KEY (idpiso) REFERENCES public.piso(numero);


--
-- Name: accesoentrada fkey_puerta_acceso; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesoentrada
    ADD CONSTRAINT fkey_puerta_acceso FOREIGN KEY (idpuerta) REFERENCES public.puerta(numero);


--
-- Name: estadia fkey_puerta_estadia_entrada; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadia
    ADD CONSTRAINT fkey_puerta_estadia_entrada FOREIGN KEY (idpuertaentrada) REFERENCES public.puerta(numero);


--
-- Name: estadia fkey_puerta_estadia_salida; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadia
    ADD CONSTRAINT fkey_puerta_estadia_salida FOREIGN KEY (idpuertasalida) REFERENCES public.puerta(numero);


--
-- Name: local fkey_sector_local; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.local
    ADD CONSTRAINT fkey_sector_local FOREIGN KEY (idsector) REFERENCES public.sector(id);


--
-- Name: estadia fkey_smartphone_estadia; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadia
    ADD CONSTRAINT fkey_smartphone_estadia FOREIGN KEY (idsmartphone) REFERENCES public.smartphone(id);


--
-- Name: factura fkey_smartphone_factura; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT fkey_smartphone_factura FOREIGN KEY (idsmartphone) REFERENCES public.smartphone(id);


--
-- Name: monitoreomesa fkey_smartphone_monitoreomesa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitoreomesa
    ADD CONSTRAINT fkey_smartphone_monitoreomesa FOREIGN KEY (idsmartphone) REFERENCES public.smartphone(id);


--
-- Name: recorrido fkey_smartphone_recorrido; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recorrido
    ADD CONSTRAINT fkey_smartphone_recorrido FOREIGN KEY (idsmartphone) REFERENCES public.smartphone(id);


--
-- Name: primerfacturadia key_factura_primerfacturadia; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.primerfacturadia
    ADD CONSTRAINT key_factura_primerfacturadia FOREIGN KEY (idfactura) REFERENCES public.factura(numero) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

